#!/usr/bin/env python

"""
  Copyright (c) 2014, SunSpec Alliance
  All Rights Reserved

"""

import sunspec.core.test.test_all as test

if __name__ == "__main__":

    test.test_all()

